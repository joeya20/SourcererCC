# str_utils_pkg

This package provides some basic string and path manipulation utility functions that
can be used across the project. It can be imported in non-UVM testbenches as
well. Please see the package for the list of available functions and their
descriptions.
