# USB20 UVM Agent

USB20 UVM Agent is extended from DV library agent classes. This is just a
skeleton implementation for now. There is no functionality available yet.
