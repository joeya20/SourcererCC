# Programmer's Guide

## Device Interface Functions (DIFs)

- [Device Interface Functions](../../../../sw/device/lib/dif/dif_rv_core_ibex.h)

## Register Table

A number of memory-mapped registers are available to control Ibex-related functionality that's specific to OpenTitan.

* [Register Table](../data/rv_core_ibex.hjson#registers)
