# Programmer's Guide

## Device Interface Functions (DIFs)

- [Device Interface Functions](../../../../sw/device/lib/dif/dif_rstmgr.h)

## Register Table

* [Register Table](../../../top_earlgrey/ip/rstmgr/data/autogen/rstmgr.hjson#registers)
