# CSRNG UVM Agent

CSRNG UVM Agent is extended from DV library agent classes.
Models host or device csrng functionality.
Contains 2 push_pull_agents, one for cmd_req and one for genbits.
