# Top Darjeeling

## Specification

Note that this folder only contains the [Darjeeling datasheet](./doc/datasheet.md).

The implementation of Darjeeling currently resides on the [integrated development branch](https://github.com/lowRISC/opentitan/tree/integrated_dev).
